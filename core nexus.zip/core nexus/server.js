// server.js
const express = require('express');
const mysql = require('mysql2/promise'); // Use promise-based MySQL library
const cors = require('cors');

const app = express();
const port = 3030;

const db1 = mysql.createPool({
    host: 'localhost',
    user: 'root',     
    password: 'Ishwari@123',  
    database: 'RS',    
});

app.use(cors());
app.use(express.json()); // Middleware to parse JSON request bodies

// Function to insert bank details into the database
async function createBank(address_location, licence_no) {
    const [result] = await db1.query(`
        INSERT INTO Bank_details (address_location, licence_no)
        VALUES (?, ?)
    `, [address_location, licence_no]);
    
    return result.insertId;
}

// Endpoint to handle POST request and create a bank
app.post('/create-bank', async (req, res) => {
    const { address_location, licence_no } = req.body;

    try {
        const insertId = await createBank(address_location, licence_no);
        res.json({ success: true, insertId });
    } catch (error) {
        console.error('Error inserting bank details:', error);
        res.status(500).json({ success: false, error: 'Failed to create bank' });
    }
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
