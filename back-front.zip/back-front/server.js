// server.js
const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');

const app = express();
const port = 3000; // Use an HTTP port for your server

// Create a connection to the MySQL database
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',     // Replace with your MySQL username
  password: 'Ishwari@123',  // Replace with your MySQL password
  database: 'bloodstock',     // Use the name of your database
});

// Connect to the database
db.connect(err => {
  if (err) throw err;
  console.log('Connected to MySQL database');
});

// Enable CORS for all requests
app.use(cors());

// Example endpoint to fetch data from the database
app.get('/api/bloodtypes', (req, res) => {
  db.query('SELECT * FROM blood_types', (err, results) => {
    if (err) {
      res.status(500).send('Error retrieving data from the database');
      return;
    }
    res.json(results);
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});